import { NextResponse } from "next/server"
import { ImapFlow } from "imapflow"
import { simpleParser } from "mailparser"
import { createEmailOSCoreDb } from "@/lib/email-os-core/db"
import { makeEmailOSId, nowIso } from "@/lib/email-os-core/schema"
import { audit } from "@/lib/email-os-core/audit"

function requireImapEnv() {
  if (!process.env.EMAIL_OS_IMAP_HOST || !process.env.EMAIL_OS_IMAP_USER || !process.env.EMAIL_OS_IMAP_PASSWORD) {
    throw new Error("Missing IMAP env vars")
  }
}

export async function POST(request: Request) {
  try {
    requireImapEnv()

    const body = await request.json().catch(() => ({}))
    const mailboxId = body.mailboxId || null
    const limit = Number(body.limit || 10)

    const db = createEmailOSCoreDb()

    const client = new ImapFlow({
      host: String(process.env.EMAIL_OS_IMAP_HOST),
      port: Number(process.env.EMAIL_OS_IMAP_PORT || 993),
      secure: String(process.env.EMAIL_OS_IMAP_SECURE || "true") !== "false",
      auth: {
        user: String(process.env.EMAIL_OS_IMAP_USER),
        pass: String(process.env.EMAIL_OS_IMAP_PASSWORD)
      }
    })

    await client.connect()
    const lock = await client.getMailboxLock("INBOX")

    const synced: Array<{ threadId: string; messageId: string; subject: string }> = []

    try {
      const status = await client.status("INBOX", { messages: true })
      const total = Number(status.messages || 0)
      const start = Math.max(1, total - limit + 1)

      for await (const message of client.fetch(`${start}:*`, { uid: true, envelope: true, source: true })) {
        const parsed = await simpleParser(message.source)
        const threadId = makeEmailOSId()
        const messageId = makeEmailOSId()
        const subject = parsed.subject || message.envelope?.subject || "(no subject)"
        const fromEmail = parsed.from?.value?.[0]?.address || ""
        const receivedAt = parsed.date?.toISOString() || nowIso()
        const preview = (parsed.text || "").slice(0, 260)

        const threadRow = {
          id: threadId,
          mailbox_id: mailboxId,
          from_email: fromEmail,
          subject,
          preview,
          status: "open",
          priority: "normal",
          owner: null,
          created_at: receivedAt,
          updated_at: nowIso()
        }

        const msgRow = {
          id: messageId,
          thread_id: threadId,
          mailbox_id: mailboxId,
          provider_uid: String(message.uid),
          from_email: fromEmail,
          to_email: parsed.to?.text || "",
          subject,
          body_text: parsed.text || "",
          received_at: receivedAt,
          created_at: nowIso()
        }

        await db.from("email_os_core_threads").upsert(threadRow)
        await db.from("email_os_core_messages").upsert(msgRow)

        synced.push({ threadId, messageId, subject })
      }
    } finally {
      lock.release()
      await client.logout()
    }

    if (mailboxId) {
      await db
        .from("email_os_core_mailboxes")
        .update({ last_synced_at: nowIso(), sync_status: "synced", sync_error: null, updated_at: nowIso() })
        .eq("id", mailboxId)
    }

    await audit("imap.synced", { targetType: "mailbox", targetId: mailboxId || "default", count: synced.length })
} catch {}

    return NextResponse.json({ ok: true, data: { count: synced.length, synced } })
  } catch (error) {
    const message = error instanceof Error ? error.message : "IMAP sync failed"

    try {
      const body = await request.json().catch(() => ({}))
      if (body.mailboxId) {
        const db = createEmailOSCoreDb()
        await db
          .from("email_os_core_mailboxes")
          .update({ sync_status: "failed", sync_error: message, updated_at: nowIso() })
          .eq("id", body.mailboxId)
      }
    } catch {}

    return NextResponse.json({ ok: false, error: message }, { status: 500 })
  }
}
