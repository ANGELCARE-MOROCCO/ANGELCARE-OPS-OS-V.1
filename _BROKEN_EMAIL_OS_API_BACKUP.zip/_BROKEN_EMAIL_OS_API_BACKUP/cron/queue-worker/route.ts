import { NextResponse } from "next/server"
import nodemailer from "nodemailer"
import { createEmailOSCoreDb } from "@/lib/email-os-core/db"
import { makeEmailOSId, nowIso } from "@/lib/email-os-core/schema"
import { writeProviderLog } from "@/lib/email-os-core/provider-log"

function cronAuthorized(request: Request) {
  const secret = process.env.EMAIL_OS_CRON_SECRET
  if (!secret) return true
  return request.headers.get("x-email-os-cron-secret") === secret
}

function smtpReady() {
  return Boolean(process.env.EMAIL_OS_SMTP_HOST && process.env.EMAIL_OS_SMTP_USER && process.env.EMAIL_OS_SMTP_PASSWORD)
}

export async function POST(request: Request) {
  try {
    if (!cronAuthorized(request)) {
      return NextResponse.json({ ok: false, error: "Unauthorized cron request" }, { status: 401 })
    }

    if (!smtpReady()) {
      try {
  await writeProviderLog({
        provider: "smtp",
        action: "cron.queue-worker",
        status: "blocked",
        message: "SMTP environment is not configured"
      })
} catch {}

      return NextResponse.json({ ok: false, error: "SMTP env not configured" }, { status: 400 })
    }

    const db = createEmailOSCoreDb()
    const { data: jobs, error } = await db
      .from("email_os_core_queue")
      .select("*")
      .in("status", ["queued", "failed"])
      .order("scheduled_at", { ascending: true })
      .limit(20)

    if (error) throw error

    const transporter = nodemailer.createTransport({
      host: process.env.EMAIL_OS_SMTP_HOST,
      port: Number(process.env.EMAIL_OS_SMTP_PORT || 587),
      secure: Number(process.env.EMAIL_OS_SMTP_PORT || 587) === 465,
      auth: {
        user: process.env.EMAIL_OS_SMTP_USER,
        pass: process.env.EMAIL_OS_SMTP_PASSWORD
      }
    })

    const results = []

    for (const job of jobs || []) {
      try {
        const payload = job.payload || {}
        const sent = await transporter.sendMail({
          from: process.env.EMAIL_OS_SMTP_FROM || process.env.EMAIL_OS_SMTP_USER,
          to: payload.toEmail,
          subject: payload.subject,
          text: payload.body
        })

        await db.from("email_os_core_queue").update({
          status: "sent",
          attempts: Number(job.attempts || 0) + 1,
          last_error: null,
          updated_at: nowIso()
        }).eq("id", job.id)

        await db.from("email_os_core_delivery_attempts").insert({
          id: makeEmailOSId(),
          queue_id: job.id,
          status: "sent",
          message_id: sent.messageId,
          error: null,
          attempted_at: nowIso()
        })

        results.push({ id: job.id, ok: true })
      } catch (sendError) {
        const message = sendError instanceof Error ? sendError.message : "Send failed"

        await db.from("email_os_core_queue").update({
          status: "failed",
          attempts: Number(job.attempts || 0) + 1,
          last_error: message,
          updated_at: nowIso()
        }).eq("id", job.id)

        await db.from("email_os_core_delivery_attempts").insert({
          id: makeEmailOSId(),
          queue_id: job.id,
          status: "failed",
          message_id: null,
          error: message,
          attempted_at: nowIso()
        })

        results.push({ id: job.id, ok: false, error: message })
      }
    }

    await writeProviderLog({
      provider: "smtp",
      action: "cron.queue-worker",
      status: "completed",
      metadata: { processed: results.length }
    })
} catch {}

    return NextResponse.json({ ok: true, data: results })
  } catch (error) {
    try {
  await writeProviderLog({
      provider: "smtp",
      action: "cron.queue-worker",
      status: "failed",
      message: error instanceof Error ? error.message : "Queue worker failed"
    })
} catch {}

    return NextResponse.json({ ok: false, error: error instanceof Error ? error.message : "Queue worker failed" }, { status: 500 })
  }
}
