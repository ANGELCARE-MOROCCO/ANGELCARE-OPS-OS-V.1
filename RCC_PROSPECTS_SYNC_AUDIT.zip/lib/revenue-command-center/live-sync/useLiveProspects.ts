"use client"

import { useCallback, useEffect, useMemo, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { normalizeProspect, type RCCProspect } from "./types"

const supabase = createClient()

function normalizeCommandProspect(row: any): RCCProspect {
  return normalizeProspect({
    ...row,
    value_mad: row.value_mad ?? row.valueMad ?? row.value ?? 0,
    data: {
      ...(row.data || {}),
      name: row.name,
      city: row.city,
      stage: row.stage,
      priority: row.priority,
      score: row.score,
      valueMad: row.value_mad ?? row.valueMad ?? row.value ?? 0,
      contactName: row.contactName,
      owner: row.owner,
      email: row.email,
      phone: row.phone,
    },
  })
}

function dedupeProspects(rows: RCCProspect[]) {
  const map = new Map<string, RCCProspect>()

  for (const row of rows) {
    if (!row.id) continue
    const existing = map.get(row.id)
    if (!existing) {
      map.set(row.id, row)
      continue
    }

    map.set(row.id, {
      ...existing,
      ...row,
      name: row.name || existing.name,
      city: row.city || existing.city,
      stage: row.stage || existing.stage,
      priority: row.priority || existing.priority,
      score: Math.max(Number(existing.score || 0), Number(row.score || 0)),
      valueMad: Math.max(Number(existing.valueMad || 0), Number(row.valueMad || 0)),
      contactName: row.contactName && row.contactName !== "N/A" ? row.contactName : existing.contactName,
      email: row.email || existing.email,
      phone: row.phone || existing.phone,
      raw: {
        ...(existing.raw || {}),
        ...(row.raw || {}),
      },
    })
  }

  return Array.from(map.values()).sort((a, b) => Number(b.score || 0) - Number(a.score || 0))
}

async function loadProspectsFromCommandApi(): Promise<RCCProspect[]> {
  try {
    const response = await fetch("/api/revenue-command-center/appointments/command", {
      method: "GET",
      cache: "no-store",
    })

    if (!response.ok) return []

    const payload = await response.json()
    const rows = Array.isArray(payload?.prospects) ? payload.prospects : []
    return rows.map(normalizeCommandProspect)
  } catch {
    return []
  }
}

export function useLiveProspects() {
  const [prospects, setProspects] = useState<RCCProspect[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string>("")
  const [lastSync, setLastSync] = useState<Date | null>(null)

  const refresh = useCallback(async () => {
    setLoading(true)
    setError("")

    const [tableResult, commandProspects] = await Promise.all([
      supabase
        .from("revenue_prospects")
        .select("*")
        .order("updated_at", { ascending: false })
        .limit(5000),
      loadProspectsFromCommandApi(),
    ])

    if (tableResult.error && commandProspects.length === 0) {
      setError(tableResult.error.message)
      setLoading(false)
      return
    }

    const tableProspects = (tableResult.data || []).map(normalizeProspect)
    const merged = dedupeProspects([...tableProspects, ...commandProspects])

    setProspects(merged)
    setLastSync(new Date())
    setLoading(false)
  }, [])

  useEffect(() => {
    void refresh()

    const channel = supabase
      .channel("rcc-live-prospects")
      .on("postgres_changes", { event: "*", schema: "public", table: "revenue_prospects" }, () => void refresh())
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [refresh])

  const byId = useMemo(() => {
    const map = new Map<string, RCCProspect>()
    prospects.forEach((p) => map.set(p.id, p))
    return map
  }, [prospects])

  return { prospects, byId, loading, error, lastSync, refresh }
}
