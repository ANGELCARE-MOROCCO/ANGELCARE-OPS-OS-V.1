"use client"

export type RCCProspect = {
  id: string
  name: string
  city: string
  stage: string
  priority: string
  score: number
  valueMad: number
  owner: string
  contactName: string
  email: string
  phone: string
  raw: any
  updatedAt?: string
}

export type RCCTask = {
  id: string
  entityId: string
  entityName?: string
  title: string
  description?: string
  status: string
  priority: string
  taskType: string
  owner: string
  assignedRole?: string
  startAt?: string | null
  endAt?: string | null
  dueDate?: string | null
  location?: string
  expectedOutcome?: string
  raw: any
  updatedAt?: string
}

export type RCCAppointment = {
  id: string
  entityId: string
  entityName?: string
  entityCity?: string
  title: string
  status: string
  appointmentType: string
  priority: string
  owner: string
  appointmentAt: string
  endAt?: string | null
  location?: string | null
  meetingLink?: string | null
  notes?: string | null
  agenda?: string | null
  objective?: string | null
  expectedOutcome?: string | null
  attendees: any[]
  reminders: any[]
  documents: any[]
  tasks: any[]
  raw: any
  updatedAt?: string
}

export function normalizeProspect(row: any): RCCProspect {
  const data = row?.data || {}
  return {
    id: String(row?.id || ""),
    name: String(row?.name || data.name || data.company || "Unnamed prospect"),
    city: String(row?.city || data.city || "Unassigned"),
    stage: String(row?.stage || data.stage || "new_lead"),
    priority: String(row?.priority || data.priority || "medium"),
    score: Number(row?.score || data.score || 0),
    valueMad: Number(row?.value_mad || data.valueMad || data.value || 0),
    owner: String(data.owner || row?.owner || "BD Officer"),
    contactName: String(data.contactName || data.decisionMaker || "N/A"),
    email: String(data.email || row?.email || ""),
    phone: String(data.phone || row?.phone || ""),
    raw: row,
    updatedAt: row?.updated_at,
  }
}

export function normalizeTask(row: any): RCCTask {
  return {
    id: String(row?.id || ""),
    entityId: String(row?.entity_id || row?.prospect_id || row?.linked_entity_id || ""),
    entityName: row?.entity_name || row?.prospect_name || undefined,
    title: String(row?.title || row?.task_title || "Untitled task"),
    description: String(row?.description || row?.execution_brief || ""),
    status: String(row?.status || "pending"),
    priority: String(row?.priority || "medium"),
    taskType: String(row?.task_type || row?.type || "follow_up"),
    owner: String(row?.owner || "BD Officer"),
    assignedRole: row?.assigned_role || undefined,
    startAt: row?.start_at || null,
    endAt: row?.end_at || null,
    dueDate: row?.due_date || row?.due_at || null,
    location: row?.location || "",
    expectedOutcome: row?.expected_outcome || "",
    raw: row,
    updatedAt: row?.updated_at,
  }
}

export function normalizeAppointment(row: any): RCCAppointment {
  return {
    id: String(row?.id || ""),
    entityId: String(row?.entity_id || ""),
    entityName: row?.entity_name || undefined,
    entityCity: row?.entity_city || undefined,
    title: String(row?.title || "Untitled appointment"),
    status: String(row?.status || "scheduled"),
    appointmentType: String(row?.appointment_type || "meeting"),
    priority: String(row?.priority || "medium"),
    owner: String(row?.owner || "BD Officer"),
    appointmentAt: String(row?.appointment_at || ""),
    endAt: row?.end_at || null,
    location: row?.location || null,
    meetingLink: row?.meeting_link || null,
    notes: row?.notes || null,
    agenda: row?.agenda || null,
    objective: row?.objective || null,
    expectedOutcome: row?.expected_outcome || null,
    attendees: Array.isArray(row?.attendees) ? row.attendees : [],
    reminders: Array.isArray(row?.reminders) ? row.reminders : [],
    documents: Array.isArray(row?.documents) ? row.documents : [],
    tasks: Array.isArray(row?.tasks) ? row.tasks : [],
    raw: row,
    updatedAt: row?.updated_at,
  }
}
