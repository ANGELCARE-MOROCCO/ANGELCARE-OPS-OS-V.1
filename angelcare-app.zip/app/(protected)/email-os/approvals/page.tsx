import EmailOsOperationalCommand from "../components/EmailOsOperationalCommand";
export default function Page(){ return <EmailOsOperationalCommand mode="approvals" />; }
