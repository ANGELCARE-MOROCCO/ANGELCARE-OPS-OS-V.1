import { DatabaseCrudPage } from "@/components/market-os/database-crud-suite"

export default function Page() {
  return <DatabaseCrudPage domain="ambassador-program" resource="ambassador_programs" mode="new" title="New Ambassador Programs" description="" />
}
