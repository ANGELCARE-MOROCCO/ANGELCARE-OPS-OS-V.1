import { DatabaseCrudPage } from "@/components/market-os/database-crud-suite"

type PageProps = { params: Promise<{ id: string }> }

export default async function Page({ params }: PageProps) {
  const { id } = await params
  return <DatabaseCrudPage domain="ambassador-program" resource="ambassador_documents" mode="edit" recordId={id} title="Edit Documents & Proofs" description="" />
}
