declare module 'mailparser';
