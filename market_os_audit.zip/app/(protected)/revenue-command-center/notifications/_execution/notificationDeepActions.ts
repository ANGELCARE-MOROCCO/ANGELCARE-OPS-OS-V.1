
'use server'
import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'

function clean(v:FormDataEntryValue|null){return String(v||'').trim()||null}

async function logEvent(supabase:any,id:string,type:string,note?:string){
  await supabase.from('bd_notification_events').insert({notification_id:id,event_type:type,note})
}

export async function assignNotification(formData:FormData){
  const supabase=await createClient()
  const id=clean(formData.get('id'))
  const owner=clean(formData.get('owner_id'))
  await supabase.from('bd_notifications').update({owner_id:owner}).eq('id',id)
  await logEvent(supabase,id,'assigned')
  revalidatePath('/revenue-command-center/notifications')
}

export async function snoozeNotification(formData:FormData){
  const supabase=await createClient()
  const id=clean(formData.get('id'))
  const hours=Number(clean(formData.get('hours'))||24)
  const until=new Date(Date.now()+hours*3600000).toISOString()
  await supabase.from('bd_notifications').update({snoozed_until:until}).eq('id',id)
  await logEvent(supabase,id,'snoozed',`+${hours}h`)
  revalidatePath('/revenue-command-center/notifications')
}

export async function convertNotificationToTask(formData:FormData){
  const supabase=await createClient()
  const id=clean(formData.get('id'))
  const title=clean(formData.get('title'))||'Task from notification'
  const {data:notif}=await supabase.from('bd_notifications').select('*').eq('id',id).maybeSingle()
  const {data:task}=await supabase.from('bd_tasks').insert({
    title,
    related_type:notif?.related_type||'notification',
    related_id:notif?.related_id||id,
    status:'open'
  }).select('id').single()
  await supabase.from('bd_notifications').update({status:'acted'}).eq('id',id)
  await logEvent(supabase,id,'converted_to_task',task?.id)
  revalidatePath('/revenue-command-center/notifications')
}

export async function resolveNotification(formData:FormData){
  const supabase=await createClient()
  const id=clean(formData.get('id'))
  await supabase.from('bd_notifications').update({status:'resolved'}).eq('id',id)
  await logEvent(supabase,id,'resolved')
  revalidatePath('/revenue-command-center/notifications')
}
