import CampaignLifecycleEngine from "@/components/market-os/campaign-lifecycle-engine"

export const dynamic = "force-dynamic"

export default function Page() {
  return <CampaignLifecycleEngine />
}
