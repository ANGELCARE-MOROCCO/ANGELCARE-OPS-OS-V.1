"use client"

import { useState } from "react"
import { dispatchMarketAction } from "@/lib/market-os/action-dispatcher"

type Props = {
  moduleKey: string
  actionKey: string
  actionLabel: string
  targetId?: string | null
  targetTitle?: string | null
  objectiveId?: string | null
  children: React.ReactNode
  className?: string
}

export default function MarketActionButton({
  moduleKey,
  actionKey,
  actionLabel,
  targetId,
  targetTitle,
  objectiveId,
  children,
  className,
}: Props) {
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)

  async function run() {
    setLoading(true)
    setDone(false)

    try {
      await dispatchMarketAction({
        moduleKey,
        actionKey,
        actionLabel,
        targetId,
        targetTitle,
        objectiveId,
      })
      setDone(true)
      setTimeout(() => setDone(false), 1800)
    } finally {
      setLoading(false)
    }
  }

  return (
    <button
      type="button"
      onClick={run}
      disabled={loading}
      className={className || "rounded-2xl bg-slate-950 px-4 py-2 text-sm font-bold text-white disabled:opacity-50"}
    >
      {loading ? "Executing..." : done ? "Done" : children}
    </button>
  )
}
