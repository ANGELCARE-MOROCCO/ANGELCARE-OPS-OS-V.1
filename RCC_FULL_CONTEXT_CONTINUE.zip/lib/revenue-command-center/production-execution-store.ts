"use client"

import { createClient } from "@/lib/supabase/client"

const supabase = createClient()

export type ProductionProspectOption = {
  id: string
  name: string
  company?: string
  city: string
  stage: string
  priority: string
  value_mad: number
  score: number
  contactName?: string
  owner?: string
  phone?: string
  email?: string
  updated_at?: string | null
}

export type ProductionTask = {
  id: string
  entity_type: string
  entity_id: string
  title: string
  description: string | null
  owner: string
  priority: "low" | "medium" | "high" | "critical"
  status: "open" | "done" | "cancelled"
  due_date: string | null
  start_at: string | null
  end_at: string | null
  task_type: string
  department: string
  assigned_role: string | null
  location: string | null
  outcome_expected: string | null
  escalation_rule: string | null
  dependencies: string | null
  tags: string[] | null
  visibility?: string | null
  reminder_minutes?: number | null
  add_to_calendar?: boolean | null
  send_notifications?: boolean | null
  completed_at: string | null
  created_at: string
  updated_at: string
  entity_name?: string
  entity_city?: string
  entity_stage?: string
  entity_priority?: string
}

export type ProductionAppointment = {
  id: string
  entity_type: string
  entity_id: string
  title: string
  appointment_at: string
  owner: string
  status: "scheduled" | "completed" | "cancelled"
  location: string | null
  notes: string | null
  created_at: string
  updated_at: string
  entity_name?: string
  entity_city?: string
  entity_stage?: string
  entity_priority?: string
}

export async function listProductionProspectOptions(query = "") {
  const url = query
    ? `/api/revenue-command-center/prospects/options?limit=2000?q=${encodeURIComponent(query)}`
    : "/api/revenue-command-center/prospects/options?limit=2000"

  const response = await fetch(url, { cache: "no-store" })
  const payload = await response.json()

  if (!response.ok || !payload.ok) {
    throw new Error(payload.error || "Unable to load live prospects from revenue_prospects")
  }

  return {
    prospects: (payload.prospects || []) as ProductionProspectOption[],
    count: Number(payload.count || 0),
    source: String(payload.source || "revenue_prospects"),
    syncedAt: String(payload.syncedAt || new Date().toISOString()),
  }
}

export async function listProductionTasks() {
  const { data, error } = await supabase
    .from("revenue_task_command_view")
    .select("*")
    .order("start_at", { ascending: true, nullsFirst: false })
    .order("due_date", { ascending: true, nullsFirst: false })
    .order("created_at", { ascending: false })

  if (error) throw error
  return (data || []) as ProductionTask[]
}

export async function createProductionTask(input: {
  entityType?: string
  entityId: string
  title: string
  description?: string
  owner?: string
  priority?: "low" | "medium" | "high" | "critical"
  dueDate?: string
  startAt?: string
  endAt?: string
  taskType?: string
  department?: string
  assignedRole?: string
  location?: string
  outcomeExpected?: string
  escalationRule?: string
  dependencies?: string
  tags?: string[]
  visibility?: string
  reminderMinutes?: number
  addToCalendar?: boolean
  sendNotifications?: boolean
}) {
  const response = await fetch("/api/revenue-command-center/tasks", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    cache: "no-store",
    body: JSON.stringify(input),
  })

  const payload = await response.json()
  if (!response.ok || !payload.ok) {
    throw new Error(payload.error || "Unable to create task")
  }

  return payload.task as ProductionTask
}

export async function updateProductionTaskStatus(taskId: string, status: "open" | "done" | "cancelled") {
  const { data, error } = await supabase
    .from("revenue_tasks")
    .update({
      status,
      completed_at: status === "done" ? new Date().toISOString() : null,
    })
    .eq("id", taskId)
    .select()
    .single()

  if (error) throw error
  return data as ProductionTask
}

export async function listProductionAppointments() {
  const { data, error } = await supabase
    .from("revenue_appointment_command_view")
    .select("*")
    .order("appointment_at", { ascending: true })

  if (error) throw error
  return (data || []) as ProductionAppointment[]
}

export async function createProductionAppointment(input: {
  entityType?: string
  entityId: string
  title: string
  appointmentAt: string
  owner?: string
  location?: string
  notes?: string
}) {
  const { data, error } = await supabase
    .from("revenue_appointments")
    .insert({
      entity_type: input.entityType || "prospect",
      entity_id: input.entityId,
      title: input.title,
      appointment_at: input.appointmentAt,
      owner: input.owner || "BD Officer",
      location: input.location || null,
      notes: input.notes || null,
      status: "scheduled",
    })
    .select()
    .single()

  if (error) throw error
  return data as ProductionAppointment
}

export async function updateProductionAppointmentStatus(appointmentId: string, status: "scheduled" | "completed" | "cancelled") {
  const { data, error } = await supabase
    .from("revenue_appointments")
    .update({ status })
    .eq("id", appointmentId)
    .select()
    .single()

  if (error) throw error
  return data as ProductionAppointment
}

export function subscribeProductionExecution(onChange: () => void) {
  const channel = supabase
    .channel("revenue-production-execution")
    .on("postgres_changes", { event: "*", schema: "public", table: "revenue_tasks" }, onChange)
    .on("postgres_changes", { event: "*", schema: "public", table: "revenue_appointments" }, onChange)
    .on("postgres_changes", { event: "*", schema: "public", table: "revenue_prospects" }, onChange)
    .subscribe()

  return () => {
    supabase.removeChannel(channel)
  }
}
