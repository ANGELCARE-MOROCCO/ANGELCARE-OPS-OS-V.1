import HRDominationWorkspace from '../_components/HRDominationWorkspace'

export default function Page() {
  return <HRDominationWorkspace kind="settings" />
}
